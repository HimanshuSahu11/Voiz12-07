export class User {
    id!:number ;
    firstname!:string;
    lastname!:string;
    dob!:Date ;
    email!:string ;
    gender!:string ;
    phoneno!:number ;
    password!:string ;

    constructor(){
        
    }

    
}
