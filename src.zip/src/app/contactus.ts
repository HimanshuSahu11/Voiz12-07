export class Contactus {
    id!:number ;
    name!:string;
    email!:string ;
    phoneno!:number;
    subject!:string ;
    message!:string ;

    constructor(){
        
    }

}
