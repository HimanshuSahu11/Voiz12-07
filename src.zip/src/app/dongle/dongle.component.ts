import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dongle',
  templateUrl: './dongle.component.html',
  styleUrls: ['./dongle.component.css']
})
export class DongleComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
