import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RegistrationService } from '../registration.service';
import { User } from '../user';

@Component({
  selector: 'app-forgotpassword',
  templateUrl: './forgotpassword.component.html',
  styleUrls: ['./forgotpassword.component.css']
})
export class ForgotpasswordComponent implements OnInit {
  user=new User();


  constructor(private _service:RegistrationService,
    private router:Router) { }

  ngOnInit(): void {
  }
  forgotUser(){
    this._service.forgotUserFromRemote(this.user).subscribe(
      data => { console.log("response recieved");
      this.router.navigateByUrl('sucess');
    },
      
      error => console.log("exception occured")
    );
  }
}
