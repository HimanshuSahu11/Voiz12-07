import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Contactus } from '../contactus';
import { RegistrationService } from '../registration.service';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
  contact=new Contactus();

  constructor(private _service:RegistrationService,
    private router:Router) { }

  ngOnInit(): void {
  }
  contactus(){
    this._service.contactusFromRemote(this.contact).subscribe(
      data => { console.log("response recieved");
      this.router.navigateByUrl('sucess');
    },
      
      error => console.log("exception occured")
    );
  }
}
