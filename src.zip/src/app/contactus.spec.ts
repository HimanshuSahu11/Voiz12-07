import { Contactus } from './contactus';

describe('Contactus', () => {
  it('should create an instance', () => {
    expect(new Contactus()).toBeTruthy();
  });
});
